
$(document).ready(function(){
    var $next = $('.js-carousel__control-next');
    var $prev = $('.js-carousel__control-prev');
    var $owlWork = $('.js-carousel');

    $owlWork.owlCarousel({
        loop: true,
        merge:true,
        autoplay:true,
        autoplayTimeout:5000,
        autoplayHoverPause:true,
        responsive : {
            // breakpoint from 0 up
            0 : {
                items: 1,
                margin: 0
            },
            // breakpoint from 480 up
            480 : {
                items: 2,
                margin: 20
            },
            // breakpoint from 768 up
            1024 : {
                items: 3,
                margin: 30
            }
        }

    });



    $next.on('click', function(){
        var $carousel = $(this).parent().find('.js-carousel')
        $carousel.trigger('next.owl.carousel');
    })
    $prev.on('click', function(){
        var $carousel = $(this).parent().find('.js-carousel')
        $carousel.trigger('prev.owl.carousel');
    })

});

(function( $ ){
    var namePlugin = 'validForm',
        __item     = '.js-valid-form__item',
        __button   = '.js-valid-form__button',
        __error    = '.js-valid-form__error';

    var methods = {
        init : function( options ) {

            return this.each(function(){

                var $this = $(this),
                    data = $this.data(namePlugin),
                    $items = $this.find(__item),
                    $inputs = $items.find('input'),
                    $buttons = $items.find(__button),
                    idTimer = null;

                 // Если плагин ещё не проинициализирован
                 if ( ! data ) {
                   //Тут выполняем инициализацию
                   $(this).data(namePlugin, {
                       target : $this
                   });
                }

                $inputs.on('validation.' + namePlugin, function(){
                    _inputValidation($(this));
                })

                $this.on('submit', function(e){
                    $inputs.trigger('validation.' + namePlugin);
                    var isValidForm = _validationForm($(this));

                    if (!isValidForm){
                        return false;
                    }

                })

                $inputs.on('keydown focusout', function(){
                    var $input = $(this);
                    clearTimeout(idTimer);

                    idTimer = setTimeout(function(){
                        _inputValidation($input);
                    }, 50)
                });

            });
        },
        destroy : function( ) {

            return this.each(function(){

             var $this = $(this),
                 data = $this.data(namePlugin);

             // пространства имён рулят!!11
             $(window).unbind('.' + namePlugin);
             $this.removeData(namePlugin);

            })

        },
        vilidation : function( ) {
            return this.each(function(){
                var $this = $(this);
                _validationForm($this);
            })
        }
    };

    function _validationForm($form){
        var $items = $form.find(__item),
            countitems = $items.length,
            countValiditems = 0,
            isValidForm = false;

        $items.each(function(){
            var $item = $(this),
                isValid = $item.data('isvalid');
                console.log('item valid = ' + isValid);
            if (isValid){
                countValiditems ++
            }
        })

        //Форма валидна, если все элементы формы прошли валидацию или элементов вовсе нет
        if ( countitems === countValiditems || countitems === 0){
            _formSucces($form)
            isValidForm = true;
        } else {
            _formFailure($form);
            isValidForm = false;
        }
        return isValidForm;
    }

    function _formSucces($form) {
        $form.data('isvalid', true);
        console.log('форма валид')
    }
    function _formFailure($form) {
        $form.data('isvalid', false);
        console.log('форма инвалид')
    }

    function _inputValidation($input){
        var $item = $input.closest(__item),
            $error = $item.find(__error),
            type = $input[0].type,
            isvalid = false,
            value = $input.val();

        if ( type == 'text'){
            if ( $input.hasClass('js-mask-phone') ){
                value = value.replace(/\+7/, '').replace(/\D/g, '');

            }
            if ( value !== '' ){
                _inputSucces($input);
                isvalid = true;
            } else {
                _inputFailure($input);
                isvalid = false;
            }
        }

        return isvalid;
    }

    function _inputSucces($input){
        var $item = $input.closest(__item),
            $error = $item.find(__error);

        $item
            .data('isvalid', true)
            .removeClass('error')
            .addClass('succes');
        $input.data('isvalid', true);
        $error.fadeOut();
    }
    function _inputFailure($input){
        var $item = $input.closest(__item),
            $error = $item.find(__error);

        $item
            .data('isvalid', false)
            .addClass('error')
            .removeClass('succes');
        $input.data('isvalid', false);
        $error.fadeIn();
    }

  $.fn[namePlugin] = function( method ) {

    if ( methods[method] ) {
      return methods[method].apply( this, Array.prototype.slice.call( arguments, 1 ));
    } else if ( typeof method === 'object' || ! method ) {
      return methods.init.apply( this, arguments );
    } else {
      $.error( 'Метод с именем ' +  method + ' не существует для jQuery.tooltip' );
    }

  };

})( jQuery );

$(document).ready(function(){
    $('.js-valid-form').validForm();
});

;$(document).ready(function(){
    var $items = $('.js-menu-items'),
        $button = $('.js-menu-button');

    $button.on('click', function(e){
        var $this = $(this);

        if ( $this.hasClass('active') ){
            hideList();
        } else {
            showList()
        }

        function hideList(){
            $this.removeClass('active');
            $items.removeClass('active');
            $(document).off('click.menu');
        }
        function showList(){
            $this.addClass('active');
            $items.addClass('active');
            $(document).on('click.menu', function(e){
                if ( $(e.target).closest($this).length ) return;
                hideList();
            })
        }
    })

});

;$(document).ready(function(){
    var $sidebar = $('.js-sidebar'),
        $button = $('.js-sidebar-button');

    $button.on('click', function(e){
        var $this = $(this);

        if ( $this.hasClass('show') ){
            hideList();
        } else {
            showList()
        }

        function hideList(){
            $this.removeClass('show');
            $sidebar.removeClass('show');
            $(document).off('click.sidebar');
        }
        function showList(){
            $this.addClass('show');
            $sidebar.addClass('show');
            $(document).on('click.sidebar', function(e){
                if ( $(e.target).closest($this).length || $(e.target).closest($sidebar).length) return;
                hideList();
            })
        }
    })

});

$(document).ready(function(){
    $('.js-select').selectize();

    $('.js-mask-phone').mask("+7 (999) 999-99-99",
        { completed:function(){
            this.trigger('validation.validForm');
            this.closest('.js-valid-form').trigger('validation.vilidForm');
            console.log('finish');
        } },
        { autoclear: false },
        { placeholder:"+7 (___) ___-__-__" });

});
